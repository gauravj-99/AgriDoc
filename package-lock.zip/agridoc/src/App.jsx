import { Routes, Route } from "react-router-dom";

import Voice from "./pages/Voice";
import Home from "./pages/Home";
import Sell from "./pages/Sell";
import Buy from "./pages/Buy";
import Detect from "./pages/Detect";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/sell" element={<Sell />} />
      <Route path="/buy" element={<Buy />} />
      <Route path="/detect" element={<Detect />} />
      <Route path="/voice" element={<Voice />} />

    </Routes>
  );
}

export default App;
