import { useState, useContext } from "react";
import { CropContext } from "../context/CropContext";
import { useNavigate } from "react-router-dom";

export default function Voice() {
  const [text, setText] = useState("");
  const { setCropData } = useContext(CropContext);
  const navigate = useNavigate();

  const SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;

  const recognition = SpeechRecognition
    ? new SpeechRecognition()
    : null;

  if (recognition) {
    recognition.lang = "en-IN";

    recognition.onresult = (event) => {
      const speech = event.results[0][0].transcript;
      setText(speech);

      // simple extraction (basic NLP)
      const quantity = speech.match(/\d+/)?.[0] || "";
      const price = speech.match(/(\d{3,5})/)?.[0] || "";
      const crop =
        speech.includes("wheat") ? "Wheat" :
        speech.includes("rice") ? "Rice" :
        speech.includes("maize") ? "Maize" : "";

      setCropData({
        crop,
        quantity,
        price,
        location: "",
      });

      navigate("/sell");
    };
  }

  return (
    <div style={{ padding: "20px" }}>
      <h2>🎙️ Speak Crop Details</h2>

      <button
        onClick={() => recognition && recognition.start()}
        style={{
          padding: "10px",
          width: "100%",
          background: "#1976d2",
          color: "white",
          border: "none",
        }}
      >
        🎤 Speak Now
      </button>

      <p style={{ marginTop: "10px" }}>{text}</p>
    </div>
  );
}
