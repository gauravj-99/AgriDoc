import { useState } from "react";

export default function Detect() {
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState(null);

  function handleImageChange(e) {
    const file = e.target.files[0];
    setImage(file);

    if (file) {
      setPreview(URL.createObjectURL(file));
    }
  }

  function handleCheck() {
    if (!image) {
      alert("Please upload a plant image first 🌱");
      return;
    }

    alert("AI is checking the crop disease... 🤖");
    // Later: send image to AI backend
  }

  return (
    <div style={{ padding: "20px", maxWidth: "500px" }}>
      <h2>🧪 Crop Disease Detection</h2>

      <input
        type="file"
        accept="image/*"
        onChange={handleImageChange}
        style={{ marginBottom: "15px" }}
      />

      {preview && (
        <div style={{ marginBottom: "15px" }}>
          <img
            src={preview}
            alt="Preview"
            style={{ width: "100%", borderRadius: "8px" }}
          />
        </div>
      )}

      <button
        onClick={handleCheck}
        style={{
          padding: "10px",
          width: "100%",
          background: "#d32f2f",
          color: "white",
          border: "none",
          cursor: "pointer",
        }}
      >
        Check Disease
      </button>
    </div>
  );
}
