import { useState, useContext, useEffect } from "react";
import { CropContext } from "../context/CropContext";

export default function Sell() {
  const { cropData } = useContext(CropContext);

  const [crop, setCrop] = useState("");
  const [quantity, setQuantity] = useState("");
  const [price, setPrice] = useState("");
  const [location, setLocation] = useState("");

  useEffect(() => {
    if (cropData) {
      setCrop(cropData.crop || "");
      setQuantity(cropData.quantity || "");
      setPrice(cropData.price || "");
      setLocation(cropData.location || "");
    }
  }, [cropData]);

  function handleSubmit(e) {
    e.preventDefault();
    alert("Crop submitted successfully 🌾");
  }

  return (
    <div style={{ padding: "20px", maxWidth: "500px" }}>
      <h2>🌾 Sell Your Crops</h2>

      <form onSubmit={handleSubmit}>
        <input value={crop} onChange={e => setCrop(e.target.value)} placeholder="Crop" />
        <br /><br />
        <input value={quantity} onChange={e => setQuantity(e.target.value)} placeholder="Quantity" />
        <br /><br />
        <input value={price} onChange={e => setPrice(e.target.value)} placeholder="Price" />
        <br /><br />
        <input value={location} onChange={e => setLocation(e.target.value)} placeholder="Location" />
        <br /><br />

        <button type="submit">Submit</button>
      </form>
    </div>
  );
}
