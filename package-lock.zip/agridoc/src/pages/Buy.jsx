const crops = [
  {
    id: 1,
    name: "Wheat",
    quantity: "50 kg",
    price: "₹2000",
    location: "Meerut",
  },
  {
    id: 2,
    name: "Rice",
    quantity: "80 kg",
    price: "₹3200",
    location: "Lucknow",
  },
  {
    id: 3,
    name: "Maize",
    quantity: "40 kg",
    price: "₹1800",
    location: "Agra",
  },
];

export default function Buy() {
  return (
    <div style={{ padding: "20px" }}>
      <h2>🛒 Buy Crops</h2>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
          gap: "15px",
        }}
      >
        {crops.map((crop) => (
          <div
            key={crop.id}
            style={{
              border: "1px solid #ccc",
              padding: "15px",
              borderRadius: "8px",
            }}
          >
            <h3>{crop.name}</h3>
            <p>Quantity: {crop.quantity}</p>
            <p>Price: {crop.price}</p>
            <p>Location: {crop.location}</p>

            <button
              style={{
                marginTop: "10px",
                padding: "8px",
                width: "100%",
                background: "#1976d2",
                color: "white",
                border: "none",
                cursor: "pointer",
              }}
            >
              Contact Seller
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
